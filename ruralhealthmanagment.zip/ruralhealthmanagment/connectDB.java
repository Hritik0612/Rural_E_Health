package com.pradnya.data;



import java.sql.Connection;
import java.sql.DriverManager;
public class connectDB
{
 static Connection con = null;
 public static Connection connect()
 {
	 try
	 {
		 if(con == null)
		 {
			 Class.forName("com.mysql.jdbc.Driver");
			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ehealth","root","");
		 }
	 }
	 catch(Exception e)
	 {
		 System.out.println(e);		 
	 }
	 return con;
 }
}
