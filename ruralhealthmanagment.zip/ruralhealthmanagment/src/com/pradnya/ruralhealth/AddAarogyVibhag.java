package com.pradnya.ruralhealth;

import java.io.IOException;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pradnya.data.connectDB;


/**
 * Servlet implementation class AddAarogyVibhag
 */
public class AddAarogyVibhag extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddAarogyVibhag() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		//int arid=0;
		int aid=0;
		String uname = request.getParameter("uname");
		String ucontact = request.getParameter("ucontact");		
		String uemail = request.getParameter("uemail");
		String upassword = request.getParameter("upassword");	
		String village = request.getParameter("village");	
		String district = request.getParameter("district");	
		int pincode = Integer.parseInt(request.getParameter("pincode"));	
	    
		try
		     {
		    	 Connection conn = connectDB.connect();
		    	 PreparedStatement ps1 = conn.prepareStatement("insert into aarogyvibhagregdata values(?,?,?,?,?,?,?,?)");
		    	  ps1.setInt(1,aid);
		    	  ps1.setString(2,uname);
		    	  ps1.setString(3,ucontact);		    	  
		    	  ps1.setString(4,uemail);
		    	  ps1.setString(5,upassword);
		    	  ps1.setString(6,village);
		    	  ps1.setString(7,district);
		    	  ps1.setInt(8,pincode);	
		    	  int res = ps1.executeUpdate();    	   
		    	  if(res>0)
					 {
						 response.sendRedirect("success.html"); 
					 }
					 else
					 {
						 response.sendRedirect("addaarogyvibhag.html");
					 }		 
		     }
		     catch(Exception e)
		     {
		    	 e.printStackTrace();
		     }
	      }		 
	
		
		
	}


