package com.pradnya.ruralhealth;

import java.io.IOException;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pradnya.data.connectDB;






/**
 * Servlet implementation class AddCase
 */
public class AddCase extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCase() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		int pid=0,did=0;
		int aid=UserInfo.getAid();
		
		String Specialistdr = "";
		String pname = request.getParameter("pname");
		int age=Integer.parseInt(request.getParameter("age"));
		String pgender = request.getParameter("pgender");
		String paddress = request.getParameter("paddress");
		String pmobile = request.getParameter("pmobile");						
		String Symptom_1 = request.getParameter("Symptom_1");
		String Symptom_2 = request.getParameter("Symptom_2");
		String Symptom_3 = request.getParameter("Symptom_3");						
		
	try{
		Connection con= connectDB.connect();
		PreparedStatement stmt = con.prepareStatement("select Disease from dataset where (Symptom_1=? and Symptom_2=?) or (Symptom_2=? and Symptom_3=?) or (Symptom_1=? and Symptom_3=?)"); 
		stmt.setString(1, Symptom_1);
		stmt.setString(2, Symptom_2);
		stmt.setString(3, Symptom_2);
		stmt.setString(4, Symptom_3);
		stmt.setString(5, Symptom_1);
		stmt.setString(6, Symptom_3);
		
		ResultSet rs=stmt.executeQuery();
	
		while(rs.next())
		{
			//Pdisease = resultSet.getString(1);
			
			System.out.println("Disease : "+rs.getString(1));
			String Disease=rs.getString(1);
			UserInfo.setDisease(Disease);
		}
		String Disease=UserInfo.getDisease();
		PreparedStatement stmt2 = con.prepareStatement("select * from specialdocregdata where Disease=?"); 
		stmt2.setString(1, UserInfo.getDisease());
		ResultSet rs1=stmt2.executeQuery();
		
		while(rs1.next())
		{
			System.out.println("Specialist Dr : "+rs1.getString(1));
			Specialistdr=rs1.getString(2);
			did = rs1.getInt(1);
		}
		UserInfo.getDisease();
		//System.out.println(Dis);
		PreparedStatement pstmt = con.prepareStatement("insert into addcase values(?,?,?,?,?,?,?,?,?,?,?,?,?)");				
		pstmt.setInt(1,pid);
		pstmt.setInt(2,aid);
		pstmt.setInt(3,did);
			pstmt.setString(4, pname);
			//UserInfo.setPname(pname);
			pstmt.setInt(5,age);
			pstmt.setString(6, pgender);
			pstmt.setString(7, paddress);
			pstmt.setString(8, pmobile);							
			pstmt.setString(9, Symptom_1);
			System.out.println(Symptom_1);
			pstmt.setString(10, Symptom_2);
			System.out.println(Symptom_2);
			pstmt.setString(11, Symptom_3);
			System.out.println(Symptom_3);
			pstmt.setString(12, Disease);
			System.out.println(Disease);
			pstmt.setString(13, Specialistdr);			
			int res=pstmt.executeUpdate();			
			if(res>0)
			{
				
				response.sendRedirect("successe1.html");
			}
			else
			{
				response.sendRedirect("addcase.jsp");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}	}

}
