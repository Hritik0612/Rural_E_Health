package com.pradnya.ruralhealth;

import java.io.IOException;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pradnya.data.connectDB;

/**
 * Servlet implementation class AddSpecialDoc
 */
public class AddSpecialDoc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddSpecialDoc() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	
	
		int Id=0;
		String dname = request.getParameter("dname");
		String dmobile = request.getParameter("dmobile");					
		String dcity = request.getParameter("dcity");
		String dspecialization = request.getParameter("dspecialization");	
		String Disease = request.getParameter("Disease");
		String demail = request.getParameter("demail");
		String dpassword = request.getParameter("dpassword");
		
		try
		     {
		    	 Connection conn = connectDB.connect();
		    	 PreparedStatement ps1 = conn.prepareStatement("insert into specialdocregdata values(?,?,?,?,?,?,?,?)");
		    	  ps1.setInt(1,Id);
		    	  ps1.setString(2,dname);
		    	  ps1.setString(3,dmobile);		    	  		    	 
		    	  ps1.setString(4,dcity);
		    	  ps1.setString(5,dspecialization);
		    	  ps1.setString(6,Disease);
		    	  ps1.setString(7,demail);
		    	//	UserInfo.setDemail(demail);
		    	  ps1.setString(8,dpassword);
		    	//	UserInfo.setDpassword(dpassword);
		    	
		    	  int res = ps1.executeUpdate();    	   
		    	  if(res>0)
					 {
		    			
						 response.sendRedirect("success.html"); 
					 }
					 else
					 {
						 response.sendRedirect("adddoctors.html");
					 }		 
		     }
		     catch(Exception e)
		     {
		    	 e.printStackTrace();
		     }
	      }		 

	}


