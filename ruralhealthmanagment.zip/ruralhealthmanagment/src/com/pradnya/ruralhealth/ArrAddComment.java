package com.pradnya.ruralhealth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pradnya.data.connectDB;


/**
 * Servlet implementation class ArrAddComment
 */
public class ArrAddComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArrAddComment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String Comment=request.getParameter("Comment");
		//System.out.println(Comment);
		try
		{
			int cid=0;
			int pid=UserInfo.getPid();

			System.out.println(pid);
			int aid=UserInfo.getAid();
			
			String dcomment=request.getParameter("Comment");			
			Connection con = connectDB.connect(); 
			PreparedStatement ps1=con.prepareStatement("insert into comment values(?,?,?,?,?)");
			ps1.setInt(1, cid); 
			ps1.setInt(2, pid);
			ps1.setString(3, "Aarogya Vibhag");
			ps1.setInt(4, aid);
			ps1.setString(5, dcomment);
			
			int rs = ps1.executeUpdate();
			if(rs>0)
			{
				response.sendRedirect("aaraddcomment1.jsp");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		/*int ID=0;
		String pname=request.getParameter("pname");
		String comment=request.getParameter("comment");
		
		try
		     {
		    	 Connection conn = connectDB.connect();
		    	 PreparedStatement ps1 = conn.prepareStatement("insert into commentviewfordoc values(?,?,?)");
		    	  ps1.setInt(1,ID);
		    	  ps1.setString(2,pname);
		    	  ps1.setString(3,comment);
		    	//  ps1.setString(3, UserInfo.getPname());
		    	  
		    	  int res = ps1.executeUpdate();    	   
		    	  if(res>0)
					 {
		    			
						 response.sendRedirect("successe1.html"); 
					 }
					 else
					 {
						 response.sendRedirect("aaraddcomment.html");
					 }		 
		     }
		     catch(Exception e)
		     {
		    	 e.printStackTrace();
		     }*/
	}

}
