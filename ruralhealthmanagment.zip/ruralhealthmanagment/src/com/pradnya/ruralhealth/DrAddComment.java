package com.pradnya.ruralhealth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pradnya.data.connectDB;



/**
 * Servlet implementation class DrAddComment
 */
public class DrAddComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DrAddComment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String Comment=request.getParameter("Comment");
		System.out.println(Comment);
		
		try
		     {
			int cid=0;
			int pid=UserInfo.getPid();

			System.out.println(pid);
			int did=UserInfo.getDid();
			String dcomment=request.getParameter("Comment");
			Connection conn = connectDB.connect();
		    	 PreparedStatement ps1 = conn.prepareStatement("insert into comment values(?,?,?,?,?)");
		    	  ps1.setInt(1, cid);
		    	  ps1.setInt(2, pid);
					ps1.setString(3, "Doctor");
					ps1.setInt(4, did);
					ps1.setString(5, dcomment);
		    	//  ps1.setString(3, UserInfo.getPname());
		    	  
		    	  int res = ps1.executeUpdate();    	   
		    	  if(res>0)
					 {
		    			
						 response.sendRedirect("draddcomment.jsp"); 
					 }
					 else
					 {
						 response.sendRedirect("doctordashboard.html");
					 }		 
		     }
		     catch(Exception e)
		     {
		    	 e.printStackTrace();
		     }
	      }		 

	
	}


