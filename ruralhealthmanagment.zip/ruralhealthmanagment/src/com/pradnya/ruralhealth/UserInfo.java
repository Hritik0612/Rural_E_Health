package com.pradnya.ruralhealth;

public class UserInfo {
	
	static String Disease;
   static String email;
   static String password;
   static String specialistdr;
   static String cid;
  public static String getCid() {
	return cid;
}

public static void setCid(String cid) {
	UserInfo.cid = cid;
}

public static String getSpecialistdr() {
	return specialistdr;
}

public static void setSpecialistdr(String specialistdr) {
	UserInfo.specialistdr = specialistdr;
}

	// static String pname;
	//static String Disease,cid,specialistdr,email;
	static int aid,pid,did,C_id;

	public static int getAid() {
		return aid;
	}

	public static void setAid(int aid) {
		UserInfo.aid = aid;
	}

	public static int getPid() {
		return pid;
	}

	public static void setPid(int pid) {
		UserInfo.pid = pid;
	}

	public static int getDid() {
		return did;
	}

	public static void setDid(int did) {
		UserInfo.did = did;
	}

	public static int getC_id() {
		return C_id;
	}

	public static void setC_id(int c_id) {
		C_id = c_id;
	}

	public static String getEmail() {
	return email;
}

public static void setEmail(String email) {
	UserInfo.email = email;
}

public static String getPassword() {
	return password;
}

public static void setPassword(String password) {
	UserInfo.password = password;
}

	public static String getDisease() {
		return Disease;
	}

	public static void setDisease(String disease) {
		Disease = disease;
	}	
}